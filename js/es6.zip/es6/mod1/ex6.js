// before
/*
const usuario = 'Diego';
const idade = 23;
console.log('O usuário ' + usuario + ' possui ' + idade + ' anos');
*/

// after
const user = 'Jéssica';
const age = 28;
console.log(`User ${user} is ${age} yeards old`);