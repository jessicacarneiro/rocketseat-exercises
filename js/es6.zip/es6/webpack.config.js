module.exports = {
    entry: './mod4/index.js',
    output: {
        path: __dirname + '/mod4',
        filename: 'bundle.js'
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader'
                }
            }
        ]
    }
};