import UserClass, { age as userAge } from './ex1.js';

UserClass.info();
console.log(userAge);