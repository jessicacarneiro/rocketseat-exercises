export const age = 28;

export default class User {
    static info() {
        console.log('Only a test');
    }
}